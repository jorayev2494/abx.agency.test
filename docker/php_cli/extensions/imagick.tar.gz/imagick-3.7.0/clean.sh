
# Delete Imagick built files without deleting items
# in subdirectories like 'make clean' does

rm *.lo
rm *.dep
rm modules/imagick.la
rm modules/imagick.so
